<div class="fixNav">
  <div class="fixNavIcons">
    <a href="<?php echo base_url()?>index.php/main/home/<?php echo $token;?>" class="fixNavIcon fixNavHome"></a>
  </div>
  <div class="fixNavIcons">
    <a href="<?php echo base_url()?>index.php/main/shop/<?php echo $token;?>" class="fixNavIcon fixNavStore"></a>
  </div>
  <div class="fixNavIcons">
    <div class="fixNavGameContainer"><a href="<?php echo base_url()?>index.php/main/play/<?php echo $token;?>" class="fixNavIcon fixNavGame"></a> </div>
  </div>
  <div class="fixNavIcons">
    <a href="<?php echo base_url()?>index.php/main/setting/<?php echo $token;?>" class="fixNavIcon fixNavSetting"></a>
  </div>
  <div class="fixNavIcons">
    <a href="<?php echo base_url()?>index.php/main/profile/<?php echo $token;?>" class="fixNavIcon fixNavProfile"></a>
  </div>
</div>
