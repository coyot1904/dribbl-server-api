
	<!-- JS Files -->
	<script>window.jQuery || document.write('<script src="<?php echo base_url()?>interface/javascripts/jquery.min.js"><\/script>')</script>
	<script src="<?php echo base_url()?>interface/javascripts/jquery.lwtCountdown-1.0.js"></script>
	<script src="<?php echo base_url()?>interface/javascripts/scripts.js"></script>
  <script src="<?php echo base_url()?>interface/javascripts/custom.js"></script>
	<!--/JS Files -->
</body>
</html>
